import 'dart:collection';

import 'package:dio/dio.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:path_provider/path_provider.dart';

import 'instd_api.dart';

class DownloadableLinksProvider extends ChangeNotifier {
  final List<DownloadableLink> _links = [];
  bool _deleteAfterComplete = false;

  bool get isEmpty => _links.isEmpty;
  int get size => _links.length;
  UnmodifiableListView<DownloadableLink> get items =>
      UnmodifiableListView(_links);

  bool setDeleteAfterComplete(bool deleteAfterComplete) {
    _deleteAfterComplete = deleteAfterComplete;
    if (deleteAfterComplete) {
      return _removeComplete();
    }
    return false;
  }

  void add(List<Link> links) {
    bool notify = false;
    for (var link in links) {
      if (!_contain(link)) {
        notify = true;
        DownloadableLink downloadableLink = DownloadableLink(link);
        _links.add(downloadableLink);
      }
    }
    if (!notify) return;
    notifyListeners();
  }

  void downloadAll() {
    for (var downloadableLink in _links) {
      if (downloadableLink.isComplete || downloadableLink.isStart) {
        continue;
      }
      downloadableLink.start();
    }
  }

  bool _removeComplete() {
    int size = _links.length;
    _links.removeWhere((element) => element.isComplete);
    bool needNotify = size != _links.length;
    if (needNotify) notifyListeners();
    return needNotify;
  }

  bool _contain(Link link) {
    for (var downloadableLink in _links) {
      if (downloadableLink.link == link) {
        return true;
      }
    }
    return false;
  }
}

class DownloadableLinkProvider extends ChangeNotifier {
  final DownloadableLink _link;

  DownloadableLink get link => _link;
  DownloadableLinkProvider(this._link) {
    this._link._listener = () => notifyListeners();
  }
}

class DownloadableLink with EquatableMixin {
  final Link link;
  bool isStart = false;
  bool isComplete = false;
  bool isFail = false;
  double percent = -1;

  CancelToken _cancelToken;
  VoidCallback _listener;
  DownloadableLink(this.link);

  void start() {
    if (this.isStart || this.isComplete) return;
    this.isFail = false;
    this.isComplete = false;
    this.percent = -1;
    this._cancelToken = CancelToken();
    this.isStart = true;
    _notifyListener();
    getTemporaryDirectory()
        .then((dir) => InstdApi()
                .download(link, dir.path + '/' + link.getFileName(),
                    callback: (count, total) {
              if (total != -1) {
                if (!isStart) return;
                this.percent = total == -1 ? -1 : 100 * count / total;
                _notifyListener();
              }
            }, cancelToken: _cancelToken).then((value) {
              ImageGallerySaver.saveFile(dir.path + '/' + link.getFileName());
            })
                //
                .then((value) => {
                      this.isComplete = true,
                      this.isStart = false,
                      this.isFail = false,
                      this.percent = 100,
                      this._cancelToken = null,
                      if (_completeListener != null) _completeListener()
                    }))
        .then((value) => _notifyListener())
        .catchError((e) => _markFailStatus(e));
  }

  void _markFailStatus(dynamic e) {
    debugPrint(e);
    this.isComplete = false;
    this.isStart = false;
    this._cancelToken = null;
    this.percent = -1;
    if (e is DioError) {
      if (e.type == DioErrorType.cancel) {
        this.isFail = false;
        _notifyListener();
        return;
      }
    }
    this.isFail = true;
    _notifyListener();
  }

  void _notifyListener() {
    if (_listener != null) _listener();
  }

  void cancel() {
    if (this._cancelToken != null) this._cancelToken.cancel();
  }

  @override
  List<Object> get props => [link, isStart, isComplete, isFail, percent];
}
