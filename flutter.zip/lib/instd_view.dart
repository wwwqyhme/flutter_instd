import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'links_provider.dart';
import 'permission.dart';

class InstdGridView extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _InstdGridViewState();
  }
}

class _InstdGridViewState extends State<InstdGridView> {
  final SliverGridDelegate _gridViewDelegate =
      SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          mainAxisSpacing: 1,
          crossAxisSpacing: 1,
          childAspectRatio: 1);

  @override
  Widget build(BuildContext context) {
    return Consumer<DownloadableLinksProvider>(
        builder: (context, provider, child) {
      int size = provider.size;
      List<DownloadableLink> links = provider.items;
      return GridView.builder(
          gridDelegate: _gridViewDelegate,
          itemCount: size,
          itemBuilder: (context, index) {
            if (index >= size) return null;
            DownloadableLink downloadableLink = links[index];
            return _GridItem(downloadableLink);
          });
    });
  }
}

class _GridItem extends StatefulWidget {
  final DownloadableLink _link;
  _GridItem(this._link);
  @override
  State<StatefulWidget> createState() => _GridItemState();
}

class _GridItemState extends State<_GridItem> {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
        create: (context) => DownloadableLinkProvider(widget._link),
        child: _createGridItemWidget());
  }

  Widget _buildThumbnailImage(DownloadableLink link) {
    return Image.network(
      link.link.thumbnailUrl,
      key: ValueKey(link.link.url),
      fit: BoxFit.cover,
      loadingBuilder: (context, child, progress) {
        if (progress == null) {
          return child;
        }
        return Center(child: CircularProgressIndicator());
      },
      errorBuilder: (context, error, stackTrace) {
        return Icon(Icons.broken_image);
      },
    );
  }

  Widget _createDownloadStatusWidget(DownloadableLink link) {
    bool visible = !(link.isStart && link.percent == -1);
    Widget child = link.isFail
        ? Icon(
            Icons.error,
            color: Colors.red,
          )
        : link.isComplete
            ? Icon(
                Icons.file_download_done,
                color: Colors.white,
              )
            : link.percent != -1
                ? Text(link.percent.toStringAsFixed(2),
                    style: TextStyle(color: Colors.green))
                : Icon(
                    Icons.file_download,
                    color: Colors.white,
                  );
    return Visibility(
      child: Positioned(
        right: 5,
        top: 5,
        child: child,
      ),
      visible: visible,
    );
  }

  Widget _createGridItemWidget() {
    return Consumer<DownloadableLinkProvider>(
        builder: (context, provider, child) {
      DownloadableLink downloadableLink = provider.link;
      return GestureDetector(
          child: Stack(
              alignment: AlignmentDirectional.bottomEnd,
              children: <Widget>[
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  child: _buildThumbnailImage(downloadableLink),
                ),
                FractionallySizedBox(
                  heightFactor: downloadableLink.percent == -1
                      ? 0
                      : downloadableLink.percent / 100,
                  child: Container(
                    color: Colors.green.withOpacity(0.5),
                  ),
                ),
                _createDownloadStatusWidget(downloadableLink),
                Visibility(
                  visible: downloadableLink.link.video,
                  child: Positioned(
                    top: 5,
                    left: 5,
                    child: Icon(Icons.video_call_rounded, color: Colors.white),
                  ),
                )
              ]),
          onTap: () async {
            if (downloadableLink.isComplete) return;
            if (downloadableLink.isStart) {
              downloadableLink.cancel();
              return;
            }
            if (await requestStoragePermission(context)) {
              downloadableLink.start();
            }
          });
    });
  }
}
